﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DisplayFlagsInPictureBox
{ /*
     Nahom Gebreyohannnies

    January 3, 2018
        
    Assignment Picture Box with Flags 
     */
    public partial class Form1 : Form
    {
        // Declare variable to hold the name of contry
        string country = "";
        public Form1()
        {
            InitializeComponent();
        }
        // When the form load the list of country added to combobox
        // and the first the list selected automaticaly
        private void Form1_Load(object sender, EventArgs e)
        {

            // Add country name to combobox
            cbCountries.Items.Add("Select Country");
            cbCountries.Items.Add("Afghanistan");
            cbCountries.Items.Add("Albania");
            cbCountries.Items.Add("Angola");
            cbCountries.Items.Add("Anguilla");
            cbCountries.Items.Add("Bangladesh");
            cbCountries.Items.Add("Belgium");
            cbCountries.Items.Add("Belize");
            cbCountries.Items.Add("Bermuda");
            cbCountries.Items.Add("Bolivia");
            cbCountries.Items.Add("United States");

            // Select the first index of combobox to show the select country string
            cbCountries.SelectedIndex = 0;
        }
        // A selcted index medthod to display image in picture
        private void cbCountries_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Assign the selected country to a string when secetion made
            country = cbCountries.GetItemText(cbCountries.SelectedItem);

            // Assign the images from resource file to picturebox
            pFlags.ImageLocation = @"C:\Users\nngebreyohannies\Documents\Visual Studio 2015\Projects\PictureBoxFlags\PictureBoxFlags\Resources\" + country + ".GIF";
        }
    }
}
